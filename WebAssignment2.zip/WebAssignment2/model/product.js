const mongoose = require("mongoose");
mongoose.connect("mongodb+srv://gregkomarn:Radio1993@marketplace.ofwz8ru.mongodb.net/", {useNewUrlParser: true, useUnifiedTopology: true});

const productSchema = new mongoose.Schema({
    name: String,
    description: String,
    price: Number,
    category: String
});

module.exports = mongoose.model("product", productSchema);