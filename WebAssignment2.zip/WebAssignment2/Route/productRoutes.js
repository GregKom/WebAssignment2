const express = require("express");
const router = express.Router();
const productController = require("../Controller/productController");

router.post("/product", productController.create);
router.get("/product", productController.read);
router.put("/product", productController.update);
router.delete("/product", productController.delete);

module.exports = router;